/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Pick_ConversationArea_Exclude_keyofConversationArea_type__ } from './Pick_ConversationArea_Exclude_keyofConversationArea_type__';

/**
 * Construct a type with the properties of T except for those in type K.
 */
export type Omit_ConversationArea_type_ = Pick_ConversationArea_Exclude_keyofConversationArea_type__;
